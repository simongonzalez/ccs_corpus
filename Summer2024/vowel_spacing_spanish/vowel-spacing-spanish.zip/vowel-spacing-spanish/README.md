# vowel-spacing-spanish

# Pre-Requisites -
1. apt install ffmpeg
2. git clone this repository - git clone https://github.com/YashHatekar/vowel-spacing-spanish.git
3. pip install -r requirements.txt
4. If step 2 fails use these package installs -
  pip3 install protobuf==3.20.2 
  pip3 install pydub 
  pip3 install omegaconf 
  pip3 install faster-whisper 
  pip3 install cython 
  pip3 install wget 
  pip3 install nemo_toolkit[asr]==1.21.0 
  pip3 install transformers
  pip3 install git+https://github.com/m-bain/whisperX.git@a5dca2cc65b1a37f32a347e574b2c56af3a7434a
  pip3 install git+https://github.com/facebookresearch/demucs#egg=demucs 
  pip3 install deepmultilingualpunctuation 

Steps to run the code -
  1. update the run_all.py file to direct to the correct path of audio files and code files.
  2. update line 15 in run_all.py to update parameters.
  3. run the file while keeping all the files in the same folder(code + audio) using python3 run_all.py

Colab notebook can be found here - https://colab.research.google.com/drive/10lczm_i-3jjZ_AglYVhaqw-PXzT_xsOs?usp=sharing
