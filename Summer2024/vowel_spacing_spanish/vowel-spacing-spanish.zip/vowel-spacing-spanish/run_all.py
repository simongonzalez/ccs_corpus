import os
import glob
import subprocess

# Path to the diarize_parallel.py script
diarize_script_path = "diarize_parallel.py"

# Path to the folder containing the .mp3 files
mp3_folder = "./Audio Here/"

# Get a list of all .mp3 files in the folder
mp3_files = glob.glob(os.path.join(mp3_folder, "*.mp3"))

# Arguments for the diarize_parallel.py script (without the folder path)
diarize_args = ["python3", diarize_script_path, "--whisper-model", "large-v1", "--no-stem"]

# Iterate over each .mp3 file and run the script with appropriate arguments
for mp3_file in mp3_files:
    diarize_command = diarize_args + ["-a", mp3_file]
    subprocess.run(diarize_command)

